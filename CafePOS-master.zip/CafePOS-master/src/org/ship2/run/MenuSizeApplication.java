package org.ship2.run;

import org.ship2.view.MenuSizeView;

public class MenuSizeApplication {

	public static void main(String[] args) {
		
		MenuSizeView sampleView = new MenuSizeView();
		sampleView.sampleDisplay();
		
	}

}
