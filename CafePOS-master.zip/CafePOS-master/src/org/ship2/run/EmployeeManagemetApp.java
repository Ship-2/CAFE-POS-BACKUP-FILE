package org.ship2.run;

import org.ship2.view.EmployeeManagement;

public class EmployeeManagemetApp {

	public static void main(String[] args) {
		EmployeeManagement test = new EmployeeManagement();
		test.EmployeeManagementTest();
		System.out.println("직원관리 테스트 종료.");
		
	}

}
