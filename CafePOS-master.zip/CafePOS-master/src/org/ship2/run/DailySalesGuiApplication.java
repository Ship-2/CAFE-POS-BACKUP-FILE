package org.ship2.run;

import java.awt.EventQueue;

import org.ship2.view.DailySalesGuiView;
import org.ship2.view.DailySalesView;

public class DailySalesGuiApplication {
	
	public static void main(String[] args) {
		
		/* 정산 gui 구현 */
		DailySalesGuiView dailySalesGuiview = new DailySalesGuiView();
		
		
		
	}
}
