package org.ship2.run;

import org.ship2.view.MembershipManagement;

public class MembershipManagementApp {

	public static void main(String[] args) {
		
		MembershipManagement membershipManagement = new MembershipManagement();
		
		membershipManagement.MembershipManagementTest();

	}

}
